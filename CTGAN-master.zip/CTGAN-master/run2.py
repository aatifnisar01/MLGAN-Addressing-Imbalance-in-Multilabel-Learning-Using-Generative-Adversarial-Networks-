# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 11:56:39 2022

@author: Aatif
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 18:53:14 2022

@author: Aatif
"""

import pandas as pd

data=pd.read_csv('C:\\Users\\Aatif\\CTGAN-master\\survey.csv')
x=data.columns

discrete_columns = [
    'Gender',
    'Country',
    'state',
    'self_employed',
    'family_history',
    'treatment',
    'work_interfere',
    'no_employees',
    'remote_work',
    'tech_company',
    'benefits',
    'care_options',
    'wellness_program',
    'seek_help',
    'anonymity',
    'leave',
    'mental_health_consequence',
    'phys_health_consequence',
    'coworkers',
    'supervisor',
    'mental_health_interview',
    'phys_health_interview',
    'mental_vs_physical',
    'obs_consequence'  
]

from ctgan import CTGANSynthesizer

ctgan = CTGANSynthesizer(verbose=True)
ctgan.fit(data, discrete_columns, epochs = 3)



samples = ctgan.sample(100)




from table_evaluator import load_data, TableEvaluator

data_shape,samples_shape=data.shape, samples.shape
table_evaluator =  TableEvaluator(data, samples, cat_cols= discrete_columns)

table_evaluator.visual_evaluation()



