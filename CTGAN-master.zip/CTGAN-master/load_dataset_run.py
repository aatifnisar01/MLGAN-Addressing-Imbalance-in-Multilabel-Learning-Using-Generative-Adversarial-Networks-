# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 18:53:14 2022

@author: Aatif
"""

import pandas as pd

data=pd.read_csv('Data.csv')
data=data.drop(['Date'],axis=1, inplace=True)

discrete_columns = [
    'Label'
]

from ctgan import CTGANSynthesizer

ctgan = CTGANSynthesizer(verbose=True)
ctgan.fit(data, discrete_columns, epochs = 2)



samples = ctgan.sample(100)




from table_evaluator import load_data, TableEvaluator

data_shape,samples_shape=data.shape, samples.shape
table_evaluator =  TableEvaluator(data, samples, cat_cols= discrete_columns)

table_evaluator.visual_evaluation()



