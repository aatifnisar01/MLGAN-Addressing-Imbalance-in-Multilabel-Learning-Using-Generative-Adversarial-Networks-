"""CTGANSynthesizer testing module."""
