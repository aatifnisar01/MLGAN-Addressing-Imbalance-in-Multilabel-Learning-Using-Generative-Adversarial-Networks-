# -*- coding: utf-8 -*-
"""
Created on Thu Jan 27 12:45:50 2022

@author: Aatif
"""

import pandas as pd
data = pd.read_csv('DATAIMADE2.csv')
df=data.loc[data['Label'] == 0]
df_one=data.loc[data['Label']==1]
discrete_columns=['workclass', 'education','marital-status','sex','Breast_cancer','Label']


from ctgan import CTGANSynthesizer

ctgan = CTGANSynthesizer(verbose=True)
ctgan.fit(df, discrete_columns, epochs = 10)
samples = ctgan.sample(10)


result = pd.concat([df_one, samples], axis=0)
X=result.iloc[:,0:9]
y=result.iloc[:,9:10]


l=y['Label'].value_counts()

# Train Test Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split( 
          X, y, test_size = 0.3, random_state = 2)



# Decision Tree
from sklearn.tree import DecisionTreeClassifier
clf_model = DecisionTreeClassifier(criterion="gini", random_state=42, max_depth=3, min_samples_leaf=5)   
clf_model.fit(X_train,y_train)
y_predict = clf_model.predict(X_test)

from sklearn import metrics
acc=metrics.accuracy_score(y_test, y_predict)

#from table_evaluator import load_data, TableEvaluator
#table_evaluator = TableEvaluator(data, result, cat_cols=discrete_columns)
#table_evaluator.visual_evaluation()
#table_evaluator.evaluate(target_col='Label')