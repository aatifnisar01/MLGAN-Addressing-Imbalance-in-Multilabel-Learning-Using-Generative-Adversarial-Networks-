Credits
=======

Research and Development Lead
-----------------------------

* Lei Xu <leix@mit.edu>

Contributors
------------

* Carles Sala <csala@csail.mit.edu>
* Kevin Kuo <kevinykuo@gmail.com>
